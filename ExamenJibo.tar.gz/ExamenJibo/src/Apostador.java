
public class Apostador {
    private String nombre;
    private String nacionalidad;
    private int edad;
    private int dinero;

    public Apostador(String nombre, String nacionalidad, int edad, int dinero) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.edad = edad;
        this.dinero = dinero;
    }

    //getter
    public String getNombre() {
        return nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public int getEdad() {
        return edad;
    }

    public int getDinero() {
        return dinero;
    }

    //setter

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setDinero(int dinero) {
        this.dinero = dinero;
    }
}
