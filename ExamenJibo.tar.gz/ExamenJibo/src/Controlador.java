import java.util.ArrayList;
import java.util.Random;

public class Controlador {

    public Controlador() {
        Random aleatorio = new Random(System.currentTimeMillis());

        int gente_random = aleatorio.nextInt(100) + 1;
        int local_random = aleatorio.nextInt(2) + 1;
        int golpea_random = aleatorio.nextInt(2) + 1;
        int peleador_random = (int) (Math.random() * 8) + 1;
        int plata_random = (int) (Math.random() * 5000);
        Peleador peleador1 = new Peleador("Jibo", "Patada voladora", "Inglesa", 1.90, 90);
        Peleador peleador2 = new Peleador("Javier", "Cabezazo", "Peruana", 1.72, 78);
        Peleador peleador3 = new Peleador("Illanes", "Rajero", "Española", 1.74, 70);
        Peleador peleador4 = new Peleador("Guevara", "Codazo en la ñata", "Francesa", 1.82, 77);
        Peleador peleador5 = new Peleador("Letelier", "Puñetazo saca-tripas", "Italiana", 1.69, 95);
        Peleador peleador6 = new Peleador("Martin", "Wate", "Mexicana", 1.75, 79);
        Peleador peleador7 = new Peleador("Luciano", "Placaje", "Argentina", 1.55, 61);
        Peleador peleador8 = new Peleador("Matias", "Rodillazo", "Chilena", 1.67, 68);
        Arbitro arbitro = new Arbitro("Tio Jaime", 50);
        Apostador apostador = new Apostador("Potrillo", "Chilena", 23, 5000);
        System.out.println("Comienza la batalla!");
        ArrayList<Peleador> peleadores = new ArrayList<>();
        peleadores.add(peleador1);
        peleadores.add(peleador2);
        peleadores.add(peleador3);
        peleadores.add(peleador4);
        peleadores.add(peleador5);
        peleadores.add(peleador6);
        peleadores.add(peleador7);
        peleadores.add(peleador8);
        for (int i = 0; peleadores.size() > 4; i = i + 2) {
            System.out.println(apostador.getNombre() + " apuesta " + (int) (Math.random() * apostador.getDinero())+" USD");
            System.out.println("Teniendo a " + arbitro.getNombre() + " como arbitro");
            System.out.println("Se enfrenta: " + peleadores.get(i).getNombre() + " con una estatura de  " + peleadores.get(i).getEstatura() + "m y un peso de " + peleadores.get(i).getPeso() + "kg");
            System.out.println("     contra: " + peleadores.get(i + 1).getNombre() + " con una estatura de  " + peleadores.get(i + 1).getEstatura() + "m y un peso de " + peleadores.get(i + 1).getPeso() + "kg \n");
            while (peleadores.get(i).getVitalidad() >= 0 || peleadores.get(i + 1).getVitalidad() >= 0) {
                if ((int) ((Math.random() * 2)) == 0) {

                    int daño = (int) (Math.random() * 5) + 1;
                    peleadores.get(i + 1).setVitalidad(peleadores.get(i + 1).getVitalidad() - daño);
                    System.out.println(peleadores.get(i).getNombre() + " golpea a " + peleadores.get(i + 1).getNombre() + " con un " + peleadores.get(i).getEspecialidad() + " quitandole " + daño + " de vida, dejandolo con " + peleadores.get(i + 1).getVitalidad() + " de vida.");
                } else {
                    int daño = (int) (Math.random() * 5) + 1;
                    peleadores.get(i).setVitalidad(peleadores.get(i).getVitalidad() - daño);
                    System.out.println(peleadores.get(i + 1).getNombre() + " golpea a " + peleadores.get(i).getNombre() + " con un " + peleadores.get(i).getEspecialidad() + " quitandole " + daño + " de vida, dejandolo con " + peleadores.get(i).getVitalidad() + " de vida.");
                    if(peleadores.get(i).getVitalidad()<=0){
                        System.out.println("Gana "+ peleadores.get(i+1).getNombre());
                        peleadores.get(i).setSigue(0);

                    }
                }
            }
        }
    }
}