public class Peleador {
    private String nombre;
    private String especialidad;
    private String nacionalidad;
    private double estatura;
    private int peso;
    private int vitalidad;
    private int sigue;

    public Peleador(String nombre, String especialidad, String nacionalidad, double estatura, int peso) {
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.nacionalidad = nacionalidad;
        this.estatura = estatura;
        this.peso = peso;
        this.vitalidad = 20;
        this.sigue = 1;

    }
    //getter
    public String getNombre() {
        return nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public double getEstatura() {
        return estatura;
    }

    public int getPeso() {
        return peso;
    }

    public int getVitalidad() {
        return vitalidad;
    }

    public int getSigue() {
        return sigue;
    }

    //setter
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public void setVitalidad(int vitalidad) {
        this.vitalidad = vitalidad;
    }

    public void setSigue(int sigue) {
        this.sigue = sigue;
    }
}
